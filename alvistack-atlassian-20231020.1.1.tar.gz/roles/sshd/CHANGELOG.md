# Ansible Role for OpenSSH Server

## 9.0.0 - TBC

## 8.5.0 - 2023-10-12

-   Support Ansible community package 8.5.0
-   Support Fedora 39
-   Support Ubuntu 23.10

## 8.4.0 - 2023-09-14

-   Support Ansible community package 8.4.0

## 8.3.0 - 2023-08-15

-   Support Ansible community package 8.3.0

## 8.2.0 - 2023-07-24

-   Support Ansible community package 8.2.0
-   Remove Ubuntu 22.10 support

## 8.1.0 - 2023-06-23

-   Support Ansible community package 8.1.0

## 8.0.0 - 2023-06-17

-   Remove Ubuntu 18.04 support
-   Remove Debian 10 support
-   Support Debian 12
-   Support openSUSE Leap 15.5
-   Support Ansible community package 8.0.0

## 7.6.0 - 2023-05-24

-   Support Ansible community package 7.6.0

## 7.5.0 - 2023-05-16

-   Remove Fedora 36 support
-   Support Fedora 38

## 7.4.0 - 2023-03-29

-   Support Ansible community package 7.4.0
-   Support Ubuntu 23.04

## 7.3.0 - 2023-03-01

-   Support Ansible community package 7.3.0

## 7.2.0 - 2023-02-01

-   Support Ansible community package 7.2.0

## 7.1.0 - 2022-12-09

-   Support Ansible community package 7.1.0

## 7.0.0 - 2022-11-26

-   Support Ansible community package 7.0.0

## 6.6.0 - 2022-11-10

-   Support Ansible community package 6.6.0
-   Remove Fedora 35 support
-   Remove openSUSE Leap 15.3 support

## 6.5.0 - 2022-10-14

-   Support Ansible community package 6.5.0

-   Support Ubuntu 22.10

-   Support Fedora 37

## 6.4.0 - 2022-09-15

-   Support Ansible community package 6.4.0

## 6.3.0 - 2022-08-24

-   Support Ansible community package 6.3.0

## 6.2.0 - 2022-08-03

-   Support Ansible community package 6.2.0

## 6.1.0 - 2022-07-14

-   Support Ansible community package 6.1.0
-   Remove Ubuntu 21.10 support

## 6.0.0 - 2022-06-22

-   Support Ansible community package 6.0.0

## 5.9.0 - 2022-06-08

-   Support Ansible community package 5.9.0

## 5.8.0 - 2022-05-20

-   Support Ansible community package 5.8.0
-   Remove Fedora 34 support

## 5.7.0 - 2022-04-27

-   Rename Ansible Role with FQCN
-   Support Ansible community package 5.7.0
-   Support RHEL 9
-   Support CentOS 9 Stream
-   Support openSUSE Leap 15.4

## 5.6.0 - 2022-04-07

-   Support Ansible community package 5.6.0
-   Support Fedora 36
-   Support Ubuntu 22.04
-   Support Ansible community package 5.5.0
-   Support Ansible community package 5.4.0

## 5.5.0 - 2022-02-11

-   Remove Ubuntu 21.04 support
-   Skip package upgrade before running molecule
-   Support Fedora Rawhide
-   Support Debian Testing

## 5.4.0 - 2021-12-31

-   Remove openSUSE Leap 15.2 support
-   Upgrade minimal Ansible community package support to 4.10

## 5.3.0 - 2021-10-20

-   Remove Fedora 33 support
-   Remove Ubuntu 20.10 support
-   Support Fedora 35
-   Support Ubuntu 21.10
-   Upgrade minimal Ansible community package support to 4.7.0

## 5.2.0 - 2021-09-19

-   Install dependencies with package manager
-   Upgrade minimal Ansible community package support to 4.5.0

## 5.1.0 - 2021-07-18

-   Move systemd service to `/etc/systemd` which generally available
-   Upgrade minimal Ansible community package support to 4.2.0
-   Support Debian 11
-   Support openSUSE Leap 15.3

## 5.0.0 - 2021-06-02

-   Upgrade minimal Ansible support to 4.0.0
-   Support Fedora 34
-   Support Ubuntu 21.04

## 4.7.0 - 2021-03-13

-   Bugfix [ansible-lint `namespace`](https://github.com/ansible-community/ansible-lint/pull/1451)
-   Bugfix [ansible-lint `no-handler`](https://github.com/ansible-community/ansible-lint/pull/1402)
-   Bugfix [ansible-lint `unnamed-task`](https://github.com/ansible-community/ansible-lint/pull/1413)
-   Simplify Python dependency with system packages
-   Support RHEL 8 with Molecule
-   Support RHEL 7 with Molecule
-   Remove CentOS 8 support
-   Support CentOS 8 Stream
-   Support openSUSE Tumbleweed
-   Migrate base Vagrant box from `generic/*` to `alvistack/*`

## 4.6.0 - 2020-12-28

-   Simplify Molecule scenario for vagrant-libvirt
-   Migrate from Travis CI to GitLab CI
-   Support Fedora 33
-   Remove Fedora 32 support
-   Support Ubuntu 20.10
-   Remove redundant tags from tasks

## 4.5.0 - 2020-08-26

-   Upgrade minimal Ansible Lint support to 4.3.2
-   Upgrade Travis CI test as Ubuntu Focal based
-   Upgrade minimal Ansible support to 2.10.0
-   Support openSUSE Leap 15.2
-   Remove Ubuntu 19.10 support

## 4.4.0 - 2020-06-04

-   Support Fedora 32
-   Support Debian 10
-   `molecule -s default` with delegated to localhost

## 4.3.0 - 2020-04-22

-   Template `molecule -s default` with dummy docker driver
-   Support CentOS/RHEL 8
-   Support Ubuntu 20.04
-   Remove Ubuntu 16.04 support
-   Upgrade minimal Molecule support to 3.0.2
-   Migrate role name to lowercase or underline
-   Migrate group name to lowercase or underline
-   Migrate molecule `group_vars` to file

## 4.2.0 - 2020-02-13

-   Migrate molecule driver to Libvirt
-   Migrate molecule verifier to Ansible
-   Support Ubuntu 19.10

## 4.1.0 - 2020-01-16

-   Default `interpreter_python` with `python3`
-   Bugfix `python3-xml` not exists for openSUSE Leap 15.1

## 4.0.0 - 2019-11-05

-   Upgrade minimal Ansible support to 2.9.0
-   Upgrade Travis CI test as Ubuntu Bionic based

## 3.5.0 - 2019-10-06

-   Support openSUSE Leap 15.1
-   Default with Python 3
-   Revamp molecule test with vagrant

## 3.4.0 - 2019-09-18

-   Run molecule test manually on Travis CI

## 3.3.0 - 2019-08-27

-   Update for RHEL 7
-   Add Vagrant test for RHEL 7
-   Restart service serially

## 3.2.0 - 2019-07-08

-   Update LXD test profile for Kubernetes v1.15.0 support
-   Fix molecule `group_vars` with links
-   Replace `with_items` with `loop`
-   Replace `with_dict` with `var`
-   Replace `with_first_found` with `lookup('first_found')`

## 3.1.0 - 2019-06-13

-   Always include default variables from `vars/main.yml`
-   Always use `become: true` with molecule, especially for vagrant
-   Improve handlers implementation
-   Reduce redundancy code by abstract service name

## 3.0.0 - 2019-05-20

-   Upgrade minimal Ansible support to 2.8.0

## 2.6.0 - 2019-05-04

-   Refine Travis CI Molecue test cases

## 2.5.0 - 2019-04-17

-   Run test with `travis_wait 120`

## 2.4.0 - 2019-03-03

-   Ensure OpenSSH host keys generated
-   Add openSUSE Leap 15 support
-   Remove CentOS 6 support

## 2.3.0 - 2019-01-30

-   Porting test to Molecule based

## 2.2.0 - 2019-01-25

-   Bugfix path for `Subsystem sftp`

## 2.1.0 - 2018-12-06

-   CI with yamllint, ansible-lint and ansible-playbook --syntax-check
-   CI with LXD, improve systemd support
-   Use shell only when shell functionality is required

## 2.0.0 - 2018-10-25

-   Upgrade Ansible support to 2.6 or higher
-   Support both Ubuntu 16.04/18.04 and RHEL/CentOS 6/7
-   Keep APT/YUM cache as-is
-   Update Travis CI test plan

## 1.1.0 - 2017-11-23

-   Ininitial release for Ansible 2.4
-   Support both Ubuntu 16.04/14.04 or RHEL/CentOS 7/6
-   Standardize /etc/ssh/sshd_config with Ubuntu 16.04 style
